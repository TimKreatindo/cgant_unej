<?php 
// var_dump($this->session->userdata('nip'));
// var_dump($user);
?>